package com.currencyforwarddemo.servlet;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = "/dollar" , initParams = 
@WebInitParam(name = "DRATE" , value = "81"))
public class DollarServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, 
	HttpServletResponse response) 
			throws ServletException, IOException {
	
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		ServletConfig config  = getServletConfig();
		int rate = Integer.parseInt(
				config.getInitParameter("DRATE"));
		
		int amt = Integer.parseInt(
				request.getParameter("txtAmount"));
		int ans = amt / rate;
		
		ServletContext context = getServletContext();
		String message = context.getInitParameter("MSG");
		
		pw.println("<!DOCTYPE html>");
		pw.println("<html>");
		pw.println("<head>");
		pw.println("<title>Dollar Page</title>");
		pw.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
		pw.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css\">");
		pw.println("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js\"></script>");
		pw.println("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js\"></script>");
		pw.println("</head>");
		pw.println("<body>");
		pw.println("<h1 style=\"color:slateblue;text-align"
		+ ":center\">" + message + " your amount in dollars "
				+ ": " + ans + "</h1>");
		pw.println("</body>");
		pw.println("</html>");
	}
}





